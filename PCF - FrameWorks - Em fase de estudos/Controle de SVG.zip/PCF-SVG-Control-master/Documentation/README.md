Assets for /README.md
